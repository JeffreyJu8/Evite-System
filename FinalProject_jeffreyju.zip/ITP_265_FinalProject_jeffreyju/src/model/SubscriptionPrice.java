package model;

public interface SubscriptionPrice {
	
	public double getSubscriptionPrice();
}
